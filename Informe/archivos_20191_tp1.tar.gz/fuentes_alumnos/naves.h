#ifndef _NAVES_H_
#define _NAVES_H_

#define NAVE_GRANDE_TOBERA_X 5
#define NAVE_GRANDE_TOBERA_Y -12

#define NAVE_CHICA_TOBERA_X 4
#define NAVE_CHICA_TOBERA_Y 9.5

extern const float nave_grande[28][2];
extern const float nave_chica[17][2];

#endif // _NAVES_H_
